const fs = require("fs");
const mongodb = require("mongodb").MongoClient;
const fastcsv = require("fast-csv");
const path = require('path');
const Client = require("ssh2-sftp-client");
const cliProgress = require("cli-progress");

const isProduction = false;

const mongoDbUrl = "mongodb://127.0.0.1:27017/";
const srcDir = isProduction ? 'PRDSerialNumbers' : 'UATSerialNumbers';
const srcDirPath = '/rajesh_r/SerialNumbers/' + srcDir;
const backupDirPath = srcDirPath + '/backup';
const localPath = __dirname + '/serial-numbers-temp-files';

const dbName = 'mukeshdb';
const collectionName = 'manufacturingNumbersWithPartyCode';

const ftpConfig = {
    host: 'xftp.bluestarindia.com',
    port: '22',
    username: 'rajesh_r',
    password: 'n4GN5:9N$Unk',
};
const client = new Client();

async function getFileNamesByFileNameStartsWith(dirPath, fileNameStartsWith) {
    return new Promise(async (resolve, reject) => {
        try {
            // Connect to the FTP server
            client.connect(ftpConfig)
                .then(() => {
                    return client.list(dirPath);
                }).then(async files => {
                const filesName = files.map(file => file.name)
                    .filter(
                        fileName => fileName.startsWith(fileNameStartsWith)
                            && (fileName.endsWith('.csv') || fileName.endsWith('.CSV'))
                    );

                // Close the FTP connection
                await client.end();
                return filesName;
            }).then((filesName) => {
                return resolve(filesName)
            }).catch(err => {
                console.error(err);
            });
        } catch (err) {
            console.error(err);
            reject(err);
        }
    })
}

async function importDataInMongoDbUsingUpdateOne(csvDataSplit, fileName) {
    const client = new mongodb(mongoDbUrl, {useNewUrlParser: true, useUnifiedTopology: true});

    const cliProgressBar = new cliProgress.SingleBar({
        format: 'Inserting Records... |' + '{bar}' + '| {percentage}% || {value}/{total}',
    }, cliProgress.Presets.shades_classic);
    let cliProgressBarCount = 0;

    try {
        await client.connect()
        const database = client.db(dbName);
        const collection = database.collection(collectionName);

        let upsertedCount = 0;
        let modifiedCount = 0;

        cliProgressBar.start(csvDataSplit.count, cliProgressBarCount);

        for (let childArray of csvDataSplit.data) {
            for (let obj of childArray) {
                cliProgressBar.update(++cliProgressBarCount);

                const data = await collection.updateOne(
                    {sn: obj.sn, bpartycode: obj.bpartycode},
                    {$set: obj},
                    {upsert: true}
                );
                upsertedCount += data.upsertedCount;
                modifiedCount += data.modifiedCount;
            }
        }

        return {fileName, upsertedCount, modifiedCount};
    } catch (e) {
        console.error(e);
    } finally {
        cliProgressBar.stop();
        await client.close();
    }
}

async function importDataInMongoDBUsingInsertMany(csvDataSplit, fileName) {
    const client = new mongodb(mongoDbUrl, {useNewUrlParser: true, useUnifiedTopology: true});

    const cliProgressBar = new cliProgress.SingleBar({
        format: 'Inserting Records... |' + '{bar}' + '| {percentage}% || {value}/{total}',
    }, cliProgress.Presets.shades_classic);
    let cliProgressBarCount = 0;

    try {
        await client.connect()
        const database = client.db(dbName);
        const collection = database.collection(collectionName);

        let insertedCount = 0;

        cliProgressBar.start(csvDataSplit.count, cliProgressBarCount);

        for (let records of csvDataSplit.data) {
            cliProgressBar.update(records.length);

            const data = await collection.insertMany(records);
            insertedCount += data.insertedCount;
        }

        return {fileName, upsertedCount: insertedCount};
    } catch (e) {
        console.error(e);
    } finally {
        cliProgressBar.stop();
        await client.close();
    }
}

function moveFile(fileName, srcPath, destinationPath) {
    return new Promise(async (resolve, reject) => {
        const srcDirPath = srcPath + '/' + fileName;
        const destinationDirPath = destinationPath + '/' + fileName;
        try {
            client.connect(ftpConfig)
                .then(async () => {
                    return client.exists(destinationDirPath);
                }).then(async (result) => {
                    if (result) {
                        await client.delete(destinationDirPath, true);
                    }
                    await client.rename(srcDirPath, destinationDirPath);
                }).then(async () => {
                console.log(`File moved successfully from ${srcDirPath} to ${destinationDirPath}`);

                // Close the FTP connection
                await client.end();
                return resolve();
            }).catch(err => {
                console.error(err);
            });
        } catch (e) {
            console.error(e);
            return reject(e);
        }
    })
}

async function downloadFileFromFTPtoLocal(fileName, localFilePath, isUpdateRequired) {
    try {
        return new Promise((resolve, reject) => {
            const remotePath = srcDirPath + '/' + fileName;
            return client.connect(ftpConfig)
                .then(async () => {
                    return client.exists(remotePath);
                })
                .then(async result => {
                    if (result) {
                        console.log("\nFile download started...");
                        return await client.get(remotePath, localFilePath, {});
                    }
                    console.error('\n!!! File Not Found at remote path : ' + remotePath);
                    return null;
                })
                .then(async (response) => {
                    if (!response) {
                        await client.end();
                        return resolve({file: remotePath, result: null});
                    }
                    console.log("\nFile download ended...");
                    console.log("Start data process... :: file: " + localFilePath);

                    const parsedCsvData = await parseCsvData(fileName, localFilePath);
                    await client.end();

                    let result;
                    if (isUpdateRequired) {
                        result = await importDataInMongoDBUsingInsertMany(parsedCsvData, fileName);
                    } else {
                        result = await importDataInMongoDbUsingUpdateOne(parsedCsvData, fileName);
                    }

                    console.log(result);
                    // move file to back up on server
                    await moveFile(fileName, srcDirPath, backupDirPath);

                    // delete local file
                    deleteFile(localFilePath);

                    return resolve();
                })
                .catch(async err => {
                    // TO DO send email for error
                    console.error(err.message)
                    await client.end();
                    reject(err);
                });
        });
    } catch (error) {
        console.error(error);
    }
}

async function parseCsvData(fileName, localFilePath) {
    return new Promise((resolve, reject) => {
        try {
            let stream = fs.createReadStream(localFilePath);
            const csvDataSplit = [];
            let csvData = [];
            let counter = 0;
            let dataCount = 0;
            let csvStream = fastcsv
                .parse()
                .on("data", function (data) {
                    if (counter !== 0) {
                        dataCount++;

                        csvData.push({
                            obdno: parseInt(data[0]),
                            model: data[1],
                            qty: parseInt(data[2]),
                            sn: data[3],
                            bpartycode: parseInt(data[4]),
                            bpartystate: parseInt(data[5]),
                            spartycode: parseInt(data[6]),
                            spartystate: parseInt(data[7]),
                            date: data[8]
                        });
                        if (csvData.length >= 25000) {
                            csvDataSplit.push(csvData);
                            csvData = [];
                        }
                    }
                    counter = counter + 1;
                })
                .on("end", function () {
                    console.log("CSV parsing completed");
                    // remove the first line: header
                    if (csvData.length > 0) {
                        csvDataSplit.push(csvData);
                    }
                    return resolve({data: csvDataSplit, count: dataCount})
                });

            stream.pipe(csvStream);
        } catch (e) {
            console.error(e);
            reject(e);
        }
    })
}

async function importSerialNumberDataInMongoDBWithoutValidation() {
    console.log("--- Process Start --- " + new Date());

    const filesNames = await getFileNamesByFileNameStartsWith(srcDirPath, 'ZSD_SERNO_VALID');
    //filesNames.reverse()
    console.log(filesNames)
    // insert records
    downloadAndInsertInMongoDBSync(filesNames, false).then(() => {
        console.log("--- Process End --- " + new Date());
    });
    // TODO send email after process completion
    return 'Process has been started!';
}

async function importSerialNumberDataInMongoDB() {
    console.log("--- Process Start --- " + new Date());

    const filesNames = await getFileNamesByFileNameStartsWith(srcDirPath, 'ZSD_SERNO_VALID');
    //filesNames.reverse()
    console.log(filesNames)
    // insert records
    downloadAndInsertInMongoDBSync(filesNames, true).then(() => {
        console.log("--- Process End --- " + new Date());
    });
    // TODO send email after process completion
    return 'Process has been started!';
}

async function downloadAndInsertInMongoDBSync(fileNames, isUpdateRequired) {
    for (let fileName of fileNames) {
        const localFilePath = path.join(localPath, fileName)
        await downloadFileFromFTPtoLocal(fileName, localFilePath, isUpdateRequired);
    }
}

function deleteFile(filePath) {
    fs.unlinkSync(filePath);
}

// importSerialNumberDataInMongoDB().then()

module.exports = {
    importSerialNumberDataInMongoDB,
    importSerialNumberDataInMongoDBWithoutValidation
}
