/**
 ## WARNING ##
 If you want to make any changes in this file
 please make sure to generate sha256 hash and include in html file where this file is used.
 ## ------- ##
 */

const ALERT_TAG = {
    SUCCESS: 'success',
    ERROR: 'error',
    INFO: 'info'
}

const HTTP_METHOD = {
    POST: 'POST',
    GET: 'GET',
}

const ENDPOINT_SERIAL_NUMBER_AND_PARTY_CODE = {
    VALIDATE: '/serialNumberAndPartyCode/validate',
    UPDATE: '/serialNumberAndPartyCode/update',
    DELETE: '/serialNumberAndPartyCode/delete',
}

function getURLParameter(p) {
    const sPageURL = window.location.search.substring(1);
    const sURLVariables = sPageURL.split('&');
    for (let i = 0; i < sURLVariables.length; i++) {
        let sParameterName = sURLVariables[i].split('=');
        if (sParameterName[0] == p) {
            return sParameterName[1].replace(/%20/g, ' ');
        }
    }
    return "";
}

window.onload = function () {
    captureSession();

    document.getElementById('topMenu').addEventListener('change', onTopMenuSelection);
    document.getElementById('topicType').addEventListener('change', onTopicTypeSelection);
    document.getElementById('yearType').addEventListener('change', onYearTypeSelection);
    document.getElementById('monthType').addEventListener('change', onMonthTypeSelection);
    document.getElementById('uploadBtn').addEventListener('click', uploadSerialNumberConfirmation);
    document.getElementById('searchBtn').addEventListener('click', searchSerialNumber);
    document.getElementById('serialNumberForValidation').addEventListener('keypress', triggerEnterKeypress);
    document.getElementById('searchSerialNumberBtn').addEventListener('click', verifySerialNumber);
    document.getElementById('reportBtn').addEventListener('click', reportSerialNumber);

    hideAllAlert();
    hideTable();
}

function triggerDatePicker(e) {
    //$("#datepicker").datepicker( "show" );
}

function captureSession() {
    this.sessionID = getURLParameter('session')
    document.getElementById('username').innerHTML = 'Welcome ' + getURLParameter('username')
    document.getElementById('lastloadtext').innerHTML = 'Last updated on'

    document.getElementById('userInfo').style.display = 'block'
    document.getElementById('lastloadstatus').style.display = 'block'

    getLastUpdatedOnDate()

}

function onTopicTypeSelection() {
    topicSelected();
    const selectedTopicType = document.getElementById('topicType').value
    const uploadFileComponent = document.getElementById('uploadFileComponent')
    const uploadFileComponent1 = document.getElementById('uploadFileComponent1')

    const materialCodeComponent = document.getElementById('materialCodeComponent')
    const fromSerialComponent = document.getElementById('fromSerialComponent')
    const toSerialComponent = document.getElementById('toSerialComponent')
    const singleSerialComponent = document.getElementById('singleSerialComponent')
    const successMessageComponent = document.getElementById('successMessageComponent')


    if (selectedTopicType == 'csvupload') {
        uploadFileComponent.style = 'display: block;'
        uploadFileComponent1.style = 'display: block;'
        materialCodeComponent.style = 'display: none;'
        fromSerialComponent.style = 'display: none;'
        toSerialComponent.style = 'display: none;'
        singleSerialComponent.style = 'display: none;'
        successMessageComponent.style = 'display: none;'

    } else if (selectedTopicType == 'rangeupload') {
        uploadFileComponent.style = 'display: none;'
        uploadFileComponent1.style = 'display: none;'

        materialCodeComponent.style = 'display: block;'
        fromSerialComponent.style = 'display: block;'
        toSerialComponent.style = 'display: block;'
        singleSerialComponent.style = 'display: none;'
        successMessageComponent.style = 'display: none;'

    } else if (selectedTopicType == 'singleupload') {
        uploadFileComponent.style = 'display: none;'
        uploadFileComponent1.style = 'display: none;'

        materialCodeComponent.style = 'display: block;'
        fromSerialComponent.style = 'display: none;'
        toSerialComponent.style = 'display: none;'
        singleSerialComponent.style = 'display: block;'
        successMessageComponent.style = 'display: none;'

    }
}

function onYearTypeSelection() {

}

function onMonthTypeSelection() {

}


function onTopMenuSelection() {
    topicSelected();

    const selectedMenu = document.getElementById('topMenu').value
    const uploadTypeComponent = document.getElementById('uploadTypeComponent')
    const uploadFileComponent = document.getElementById('uploadFileComponent')
    const uploadFileComponent1 = document.getElementById('uploadFileComponent1')
    const reportTypeComponent = document.getElementById('reportTypeComponent')

    const singleSerialComponent = document.getElementById('singleSerialComponent')
    const verifySerialNumberValidationComponent = document.getElementById('verifySerialNumberValidationComponent')
    const uploadButtonComponent = document.getElementById('uploadButtonComponent')
    const searchButtonComponent = document.getElementById('searchButtonComponent')
    const searchSerialNumberButtonComponent = document.getElementById('searchSerialNumberButtonComponent')
    const reportButtonComponent = document.getElementById('reportButtonComponent')

    const remarksComponent = document.getElementById('remarksComponent')

    hideAllComponent();

    if (selectedMenu === 'upload') {
        uploadTypeComponent.style = 'display: block;'
        uploadFileComponent.style = 'display: block;'
        uploadFileComponent1.style = 'display: block;'
        uploadButtonComponent.style = 'display: block;'
        remarksComponent.style = 'display: block;'
    } else if (selectedMenu === 'search') {
        singleSerialComponent.style = 'display: block;'
        searchButtonComponent.style = 'display: block;'
    } else if (selectedMenu === 'report') {
        reportTypeComponent.style = 'display: block;'
        reportButtonComponent.style = 'display: block;'
    } else if (selectedMenu === 'verify-serial-number-validation') {
        verifySerialNumberValidationComponent.style = 'display: block;'
        searchSerialNumberButtonComponent.style = 'display: block;'
    }
}

function hideAllComponent() {
    const uploadTypeComponent = document.getElementById('uploadTypeComponent')
    const uploadFileComponent = document.getElementById('uploadFileComponent')
    const uploadFileComponent1 = document.getElementById('uploadFileComponent1')
    const reportTypeComponent = document.getElementById('reportTypeComponent')

    const materialCodeComponent = document.getElementById('materialCodeComponent')
    const fromSerialComponent = document.getElementById('fromSerialComponent')
    const toSerialComponent = document.getElementById('toSerialComponent')
    const singleSerialComponent = document.getElementById('singleSerialComponent')
    const verifySerialNumberValidationComponent = document.getElementById('verifySerialNumberValidationComponent')
    const successMessageComponent = document.getElementById('successMessageComponent')
    const uploadButtonComponent = document.getElementById('uploadButtonComponent')
    const searchButtonComponent = document.getElementById('searchButtonComponent')
    const searchSerialNumberButtonComponent = document.getElementById('searchSerialNumberButtonComponent')
    const reportButtonComponent = document.getElementById('reportButtonComponent')
    const alertSuccessComponent = document.getElementById('alert-success')
    const alertErrorComponent = document.getElementById('alert-error')
    const alertInfoComponent = document.getElementById('alert-info')
    const serialNumberDataTableComponent = document.getElementById('serial-number-data-table')

    const remarksComponent = document.getElementById('remarksComponent')

    uploadTypeComponent.style = 'display: none';
    uploadFileComponent.style = 'display: none';
    uploadFileComponent1.style = 'display: none';
    materialCodeComponent.style = 'display: none';
    fromSerialComponent.style = 'display: none';
    toSerialComponent.style = 'display: none';
    singleSerialComponent.style = 'display: none';
    verifySerialNumberValidationComponent.style = 'display: none';
    successMessageComponent.style = 'display: none';
    uploadButtonComponent.style = 'display: none';
    searchButtonComponent.style = 'display: none';
    searchSerialNumberButtonComponent.style = 'display: none';
    remarksComponent.style = 'display: none';
    reportTypeComponent.style = 'display: none';
    reportButtonComponent.style = 'display: none';

    hideDOM(alertSuccessComponent)
    hideDOM(alertErrorComponent)
    hideDOM(alertInfoComponent)
    hideDOM(serialNumberDataTableComponent)
}

function clearFormElements() {
}

function topicSelected() {
}

function uploadSerialNumberConfirmation() {
    const r = confirm("Do you really want to upload?");
    if (r == true) {
        var spinner = new jQuerySpinner({
            parentId: 'supercontainer'
        });
        spinner.show()


        var successMessageComponent = document.getElementById('successMessageComponent')
        successMessageComponent.style = 'display: block;'

        const selectedTopicType = document.getElementById('topicType').value
        if (selectedTopicType == 'csvupload') {
            uploadSerialNumber(spinner)
        } else if (selectedTopicType == 'rangeupload') {
            rangeUpload(spinner)
        } else if (selectedTopicType == 'singleupload') {
            singleUpload(spinner)
        }
    }
}

function searchSerialNumber() {
    const spinner = new jQuerySpinner({
        parentId: 'supercontainer'
    });
    spinner.show()

    const successMessageComponent = document.getElementById('successMessageComponent');
    successMessageComponent.style = 'display: block;'

    searchSerial(spinner)
}

function reportSerialNumber() {
    const spinner = new jQuerySpinner({
        parentId: 'supercontainer'
    });
    spinner.show()

    const successMessageComponent = document.getElementById('successMessageComponent');
    successMessageComponent.style = 'display: block;'

    generateReport(spinner)
}

function generateReport(spinner) {
    const yearVal = document.getElementById('yearType').value
    const monthVal = document.getElementById('monthType').value

    const requestBody = {
        "month": monthVal,
        "year": yearVal
    }
    fetch("/generateReport",
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json',
                'session': this.sessionID
            },
            body: JSON.stringify(requestBody)
        }).then(response => {
        return response.json()
    }).then(output => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = '<p>' + output.message + '</p><br><p>' + output.status + '</p>'
        clearFormElements()
    }).catch(error => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = error
    })
}

function rangeUpload(spinner) {
    const mCode = document.getElementById('materialCode').value
    const fromSerialNumber = document.getElementById('fromSerial').value
    const toSerialNumber = document.getElementById('toSerial').value
    const remarks = document.getElementById('remarks').value


    const requestBody = {
        "mCode": mCode,
        "fromSerialNumber": fromSerialNumber,
        "toSerialNumber": toSerialNumber,
        "remarks": remarks
    }
    fetch("/rangeSerialUpload",
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json',
                'session': this.sessionID
            },
            body: JSON.stringify(requestBody)
        }).then(response => {
        return response.json()
    }).then(output => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = output.status
        clearFormElements()
    }).catch(error => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = error
    })
}

function singleUpload(spinner) {
    const mCode = document.getElementById('materialCode').value
    const serialNumber = document.getElementById('singleSerial').value
    const remarks = document.getElementById('remarks').value

    const requestBody = {
        "mCode": mCode,
        "serialNumber": serialNumber,
        "remarks": remarks
    }
    fetch("/singleSerialUpload",
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json',
                'session': this.sessionID
            },
            body: JSON.stringify(requestBody)
        }).then(response => {
        return response.json()
    }).then(output => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = output.status
        clearFormElements()
    }).catch(error => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = error
    })
}

function searchSerial(spinner) {
    const serialNumber = document.getElementById('singleSerial').value

    const requestBody = {
        "serialNumber": serialNumber
    }

    fetch("/bsl-finapi/searchSerial",
        {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json',
                'session': this.sessionID
            },
            body: JSON.stringify(requestBody)
        }).then(response => {
        return response.json()
    }).then(output => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = output.message
        clearFormElements()
    }).catch(error => {
        spinner.hide()
        document.getElementById("success_message").innerHTML = error
    })
}

function uploadSerialNumber(spinner) {

    document.getElementById("success_message").innerHTML = 'Uploading Serial Numbers...'
    const remarks = document.getElementById('remarks').value
    const files = document.getElementById("imageURL").files;
    const formData = new FormData();
    formData.append('myFile', files[0]);
    const uploadurl = "/upload?remarks=" + btoa(remarks);
    fetch(uploadurl, {
        method: 'POST',
        body: formData,
        headers: {
            'session': this.sessionID
        }
    })
        .then(response => {
            return response.json()
        })
        .then(data => {
            spinner.hide()
            document.getElementById("success_message").innerHTML = data.status
        })
        .catch(error => {
            spinner.hide()
            document.getElementById("success_message").innerHTML = error
        })
}

function getLastUpdatedOnDate() {
    fetch("/lastupdatedon",
        {
            method: 'GET',
            headers: {
                'Content-Type': 'application/json; charset=UTF-8',
                'Accept': 'application/json',
                'session': this.sessionID
            }
        }).then(response => {
        return response.json()
    }).then(output => {
        document.getElementById("lastloadtext").innerHTML = "Last updated on " + output.lastupdatedon
        clearFormElements()
    }).catch(error => {
        document.getElementById("lastloadtext").innerHTML = "Last updated on"
    })
}

// --- Serial Number Validation ---

function triggerEnterKeypress(event) {
    // If the user presses the "Enter" key on the keyboard
    if (event.key === "Enter") {
        // Cancel the default action, if needed
        event.preventDefault();
        // Trigger the button element with a click
        document.getElementById("searchSerialNumberBtn").click();
    }
}

function hideTable() {
    const table = document.getElementById('serial-number-data-table');
    hideDOM(table);
}

function hideAllAlert() {
    let alertDialog_error = document.getElementById('alert-' + ALERT_TAG.ERROR);
    let alertDialog_success = document.getElementById('alert-' + ALERT_TAG.SUCCESS);
    let alertDialog_info = document.getElementById('alert-' + ALERT_TAG.INFO);

    hideDOM(alertDialog_error)
    hideDOM(alertDialog_success)
    hideDOM(alertDialog_info)
}

function showAlert(alert, message) {
    hideAllAlert();

    // show alert
    const textDiv = document.getElementsByClassName('text-' + alert);
    textDiv.innerHtml = message;

    let alertDialog = document.getElementById('alert-' + alert);
    alertDialog.children[1].innerHTML = message;
    alertDialog.children[2].addEventListener('click', () => {
        hideDOM(alertDialog)
    });
    showDOM(alertDialog);
}

function hideDOM(dom) {
    if (!dom.classList.contains("display-none-important")) {
        dom.classList.toggle("display-none-important");
    }
}

function showDOM(dom) {
    if (dom.classList.contains("display-none-important")) {
        dom.classList.toggle("display-none-important");
    }
}

function verifySerialNumberValidation(serialNumber) {
    console.log('serial number', serialNumber)
    return new Promise(async (resolve, reject) => {
        const requestBody = {serial_number: serialNumber}

        try {
            const res = await fetchAPI(
                HTTP_METHOD.POST,
                ENDPOINT_SERIAL_NUMBER_AND_PARTY_CODE.VALIDATE,
                requestBody);
            return resolve(res);
        } catch (e) {
            return reject(e);
        }
    })
}

async function onUpdateSerialNumber(updatedData) {
    try {
        const res = await fetchAPI(
            HTTP_METHOD.POST,
            ENDPOINT_SERIAL_NUMBER_AND_PARTY_CODE.UPDATE,
            updatedData);
        if (res.status === '-2') {
            showAlert(ALERT_TAG.SUCCESS, res.message);
        } else if (res.status === '-3') {
            showAlert(ALERT_TAG.INFO, res.message);
        } else {
            showAlert(ALERT_TAG.ERROR, res.message);
        }
    } catch (e) {
        console.log(e);
        showAlert(ALERT_TAG.ERROR, e.message);
    }
}

async function onDeleteSerialNumber(body) {
    try {
        const res = await fetchAPI(
            HTTP_METHOD.POST,
            ENDPOINT_SERIAL_NUMBER_AND_PARTY_CODE.DELETE,
            body);
        if (res.status === '-2') {
            showAlert(ALERT_TAG.SUCCESS, res.message);
        } else if (res.status === '-3') {
            showAlert(ALERT_TAG.INFO, res.message);
        } else {
            showAlert(ALERT_TAG.ERROR, res.message);
        }
    } catch (e) {
        console.log(e);
        showAlert(ALERT_TAG.ERROR, e.message);
    }
}

function editSerialNumberDataRow() {
    document.getElementById("serial-number-data-edit-btn").style.display = "none";
    document.getElementById("serial-number-data-save-btn").style.display = "inline-block";

    const serial_number = document.getElementById('serial_number');
    const b_party_code = document.getElementById('b_party_code');
    const b_party_state = document.getElementById('b_party_state');
    const s_party_code = document.getElementById('s_party_code');
    const s_party_state = document.getElementById('s_party_state');

    serial_number.innerHTML = "<input type='text' class='editable_cell form-control' id='text_serial_number' disabled value='" + serial_number.innerHTML + "'>";
    b_party_code.innerHTML = "<input type='text' class='editable_cell form-control' id='text_b_party_code' value='" + b_party_code.innerHTML + "'>";
    b_party_state.innerHTML = "<input type='text' class='editable_cell form-control' id='text_b_party_state' value='" + b_party_state.innerHTML + "'>";
    s_party_code.innerHTML = "<input type='text' class='editable_cell form-control' id='text_s_party_code' value='" + s_party_code.innerHTML + "'>";
    s_party_state.innerHTML = "<input type='text' class='editable_cell form-control' id='text_s_party_state' value='" + s_party_state.innerHTML + "'>";
}

async function saveSerialNumberDataRow() {
    const text_serial_number = document.getElementById('text_serial_number');
    const text_b_party_code = document.getElementById('text_b_party_code');
    const text_b_party_state = document.getElementById('text_b_party_state');
    const text_s_party_code = document.getElementById('text_s_party_code');
    const text_s_party_state = document.getElementById('text_s_party_state');

    const serial_number = document.getElementById('serial_number');
    const b_party_code = document.getElementById('b_party_code');
    const b_party_state = document.getElementById('b_party_state');
    const s_party_code = document.getElementById('s_party_code');
    const s_party_state = document.getElementById('s_party_state');

    serial_number.innerHTML = text_serial_number.value;
    b_party_code.innerHTML = text_b_party_code.value;
    b_party_state.innerHTML = text_b_party_state.value;
    s_party_code.innerHTML = text_s_party_code.value;
    s_party_state.innerHTML = text_s_party_state.value;

    // toggle save and edit btn
    document.getElementById("serial-number-data-edit-btn").style.display = "inline-block";
    document.getElementById("serial-number-data-save-btn").style.display = "none";

    const data = {
        serial_number: text_serial_number.value,
        b_party_code: parseInt(text_b_party_code.value),
        b_party_state: parseInt(text_b_party_state.value),
        s_party_code: parseInt(text_s_party_code.value),
        s_party_state: parseInt(text_s_party_state.value),
    }
    await onUpdateSerialNumber(data);
}

function deleteSerialNumberDataRow() {
    const serial_number = document.getElementById('serial_number').innerText;

    const body = {serial_number}
    onDeleteSerialNumber(body);
    hideTable();
}

async function showTable(serialNumberDetails, disableActions) {
    const table = document.getElementById('serial-number-data-table');
    showDOM(table);

    const serial_number = document.getElementById('serial_number');
    const b_party_code = document.getElementById('b_party_code');
    const b_party_state = document.getElementById('b_party_state');
    const s_party_code = document.getElementById('s_party_code');
    const s_party_state = document.getElementById('s_party_state');

    serial_number.innerHTML = serialNumberDetails.data[0]?.sn;
    b_party_code.innerHTML = serialNumberDetails.data[0]?.bpartycode;
    b_party_state.innerHTML = serialNumberDetails.data[0]?.bpartystate;
    s_party_code.innerHTML = serialNumberDetails.data[0]?.spartycode;
    s_party_state.innerHTML = serialNumberDetails.data[0]?.spartystate;

    const editBtn = document.getElementById('serial-number-data-edit-btn');
    const saveBtn = document.getElementById('serial-number-data-save-btn');
    const deleteBtn = document.getElementById('serial-number-data-delete-btn');

    if (disableActions) {
        disableTableActions(editBtn, saveBtn, deleteBtn);
    } else {
        enableTableActions(editBtn, saveBtn, deleteBtn);

        editBtn.addEventListener('click', editSerialNumberDataRow);
        saveBtn.addEventListener('click', saveSerialNumberDataRow);
        deleteBtn.addEventListener('click', deleteSerialNumberDataRow);
    }
}

function enableTableActions(editBtn, saveBtn, deleteBtn) {
    editBtn.disabled = false;
    saveBtn.disabled = false;
    deleteBtn.disabled = false;

    editBtn.style = 'color: #007bff; border-color: #007bff;'
    saveBtn.style = 'color: #28a745; border-color: #28a745;'
    deleteBtn.style = 'color: #dc3545; border-color: #dc3545;'
}

function disableTableActions(editBtn, saveBtn, deleteBtn) {
    editBtn.disabled = true;
    saveBtn.disabled = true;
    deleteBtn.disabled = true;

    editBtn.style = 'color: #666a6e; border-color: #666a6e;'
    saveBtn.style = 'color: #666a6e; border-color: #666a6e;'
    deleteBtn.style = 'color: #666a6e; border-color: #666a6e;'
}

async function verifySerialNumber() {
    const serialNumber = document.getElementById('serialNumberForValidation').value.trim();
    console.log('entered serial no.', serialNumber)
    hideTable();

    if (serialNumber === '') {
        showAlert(ALERT_TAG.ERROR, 'Serial Number cannot be blank!');
    } else {
        try {
            const result = await verifySerialNumberValidation(serialNumber);
            console.log('result', result)
            if (result.status === '-2') {
                showAlert(ALERT_TAG.SUCCESS, result.message);
                await showTable(result, true);
            } else if (result.status === '-3') {
                showAlert(ALERT_TAG.INFO, result.message);
                await showTable(result, false);
            } else if (result.status === '-4') {
                showAlert(ALERT_TAG.SUCCESS, result.message);
            } else {
                showAlert(ALERT_TAG.ERROR, result.message);
            }
        } catch (error) {
            showAlert(ALERT_TAG.ERROR, error.message);
        }
    }
}

async function fetchAPI(method, endpoint, body) {
    return new Promise((resolve, reject) => {
        const spinner = new jQuerySpinner({parentId: 'supercontainer'});
        spinner.show();
        try {
            fetch(endpoint,
                {
                    method,
                    headers: {
                        'Content-Type': 'application/json; charset=UTF-8',
                        'Accept': 'application/json',
                        'session': this.sessionID
                    },
                    body: JSON.stringify(body)
                }).then(response => {
                spinner.hide()
                return resolve(response.json());
            });
        } catch (e) {
            spinner.hide()
            return reject({
                status: '-1',
                message: 'Error fetching API ' + e.message
            });
        }
    })
}

// --- /Serial Number Validation ---
