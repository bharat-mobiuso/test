/**
 ## WARNING ##
 If you want to make any changes in this file
 please make sure to generate sha256 hash and include in html file where this file is used.
 ## ------- ##
 */

$(document).ready(function () {
    $('[data-toggle="tooltip"]').tooltip();
});
