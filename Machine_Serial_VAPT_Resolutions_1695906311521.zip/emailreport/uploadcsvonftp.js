var fs = require('fs');
var SSH2Client = require('ssh2').Client;

var connSettings = {
  host: 'ftp.bluestarindia.com',
  port: 22, // Normal is 22 port
  username: 'rajesh_r',
  password: 'r@j3sh@321'
  // You can use a key file too, read the ssh2 documentation
};

var conn = new SSH2Client();
conn.on('ready', function() {
    conn.sftp(function(err, sftp) {
         if (err) throw err;
         
        var fs = require("fs"); // Use node filesystem
        var readStream = fs.createReadStream( "/home/ubuntu/Harry/emailreport/csv/manufacturing.csv" );
        var writeStream = sftp.createWriteStream( "/SerialNumbers/aws/manufacturing.csv" );

        writeStream.on('close',function () {
            console.log( "- file transferred succesfully" );
        });

        writeStream.on('end', function () {
            console.log( "sftp connection closed" );
            conn.close();
        });

        // initiate transfer of file
        readStream.pipe( writeStream );
    });
}).connect(connSettings);

var conn1 = new SSH2Client();
conn1.on('ready', function() {
    conn1.sftp(function(err, sftp) {
         if (err) throw err;
         
        var fs = require("fs"); // Use node filesystem
        var readStream = fs.createReadStream( "/home/ubuntu/Harry/emailreport/csv/tradedserial.csv" );
        var writeStream = sftp.createWriteStream( "/SerialNumbers/aws/tradedserial.csv" );

        writeStream.on('close',function () {
            console.log( "- file transferred succesfully" );
        });

        writeStream.on('end', function () {
            console.log( "sftp connection closed" );
            conn.close();
        });

        // initiate transfer of file
        readStream.pipe( writeStream );
    });
}).connect(connSettings);

var conn2 = new SSH2Client();
conn2.on('ready', function() {
    conn2.sftp(function(err, sftp) {
         if (err) throw err;
         
        var fs = require("fs"); // Use node filesystem
        var readStream = fs.createReadStream( "/home/ubuntu/Harry/emailreport/csv/validatedserialnumbers.csv" );
        var writeStream = sftp.createWriteStream( "/SerialNumbers/aws/validatedserialnumbers.csv" );

        writeStream.on('close',function () {
            console.log( "- file transferred succesfully" );
        });

        writeStream.on('end', function () {
            console.log( "sftp connection closed" );
            conn.close();
        });

        // initiate transfer of file
        readStream.pipe( writeStream );
    });
}).connect(connSettings);

