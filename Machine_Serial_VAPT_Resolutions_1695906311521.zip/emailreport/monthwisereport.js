const nodemailer = require('nodemailer');
const MongoClient = require('mongodb').MongoClient;
var moment = require('moment-timezone');
const { parse } = require('json2csv');
const fs = require('fs');


//var currentMonth = moment().tz("Asia/Kolkata").format('MM-YYYY');
var currentMonth = "08-2020";
currentMonth = ".*" + currentMonth;

MongoClient.connect('mongodb://127.0.0.1:27017', { useNewUrlParser: true, useUnifiedTopology: true }, (err, client) => {
        if (err) return console.log(err);
        serialnumberdb = client.db('mukeshdb');
        serialnumberdb.collection("validatedserialnumbers").find({ "validatedOnDate": { '$regex': currentMonth } }).toArray(function (err1, result) {
                client.close();
                if(result.length > 0)
                {
                        saveCSVFile(result);
                }
        });
});

function saveCSVFile(resultArray)
{
        var newResultList = [];
        for (resultObj of resultArray)
        {
                var newResultObj = {};
                newResultObj["Material Code"] = resultObj.materialCode;
                newResultObj["Material Serial Number"] = resultObj.serialNumber;
                newResultObj["Validated By Channel Finance Co"] = resultObj.validatedByName;
                newResultObj["Validation Done On"] = resultObj.validatedOnDate;
                newResultObj["Validation Time"] = resultObj.validatedOnTime;
                newResultObj["Uploaded By User ID"] = resultObj.uploadedBy;
                newResultObj["Uploaded On"] = resultObj.uploadedDate;
                newResultObj["Category"] = resultObj.serialNumberType;

                if(resultObj.isException == false)
                {
                        newResultObj["Exception Upload"] = "";
                }
                else
                {
                        newResultObj["Exception Upload"] = "E";
                }
                newResultList.push(newResultObj);
        }

        const fields = ['Material Code', 'Material Serial Number','Validated By Channel Finance Co','Validation Done On','Validation Time','Uploaded By User ID','Uploaded On','Category','Exception Upload'];
        const opts = { fields };

        try {
            const csv = parse(newResultList, opts);
            csvfilename = "CurrentMonthValidatedSerialNumbers.csv";
            fs.writeFile("/home/ubuntu/Harry/emailreport/csv/" + csvfilename, csv, (err) => {
                sendEmail();
            });

        } catch (err) {
            console.error(err);
        }
}

function sendEmail() {
        let transport = nodemailer.createTransport({
                host: 'smtp.sendgrid.com',
                port: 587,
                pool: true,
                auth: {
                        user: 'connect@bluestarindia.com',
                        pass: 'P@ssw0rd'
                },
                tls: {
                        rejectUnauthorized: false
                }
        });

        const message = {
                from: 'connect@bluestarindia.com', // Sender address
                to: "harvindarsharma@bluestarindia.com",         // List of recipients
                subject: "Validated Serial Numbers", // Subject line
                text: "Dear Team,\n\nPlease find enclosed here with summary of the machine serial number validated by different consumer finance company along with the records uploaded as an exception.\n\nBest Regards,\nIT Team\n\n", // Plain text body
                attachments: [{ filename: "CurrentMonthValidatedSerialNumbers.csv", path: "/home/ubuntu/Harry/emailreport/csv/CurrentMonthValidatedSerialNumbers.csv" }]
        };

        transport.sendMail(message, function (err, info) {
                if (err) {
                        console.log("Error");
                        console.log(err);
                } else {
                        console.log("Success");
                        console.log(info);
                }
        });
}

