const nodemailer = require('nodemailer');

let transport = nodemailer.createTransport({
                host: 'smtp.sendgrid.com',
                port: 587,
                pool: true,
                auth: {
                user: 'connect@bluestarindia.com',
                pass: 'P@ssw0rd'
                },
                tls: {
                rejectUnauthorized: false
                }
        });

const message = {
                from: 'connect@bluestarindia.com', // Sender address
                to: "harvindarsharma@bluestarindia.com",         // List of recipients
                subject: "Validated Serial Numbers", // Subject line
                text: "Dear Team,\n\nPlease find enclosed here with summary of the machine serial number validated by different consumer finance company along with the records uploaded as an exception.\n\nBest Regards,\nIT Team\n\n", // Plain text body
                attachments:[{filename:"validatedserialnumbers.csv",path:"/home/ubuntu/Harry/emailreport/csv/validatedserialnumbers.csv"}]
        };

transport.sendMail(message, function(err, info) {
                if (err) {
                        console.log("Error");
                        console.log(err);
                } else {
                        console.log("Success");
                        console.log(info);
                }
        });
