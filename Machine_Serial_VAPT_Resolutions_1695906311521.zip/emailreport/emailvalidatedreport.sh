#!/bin/bash

#mongoexport --db mukeshdb --collection manufacturingserial --type=csv --fields mc,sn,date  --out /home/ubuntu/Harry/emailreport/csv/manufacturing.csv

#mongoexport --db mukeshdb --collection tradedserial --type=csv --fields mCode,serialNumber,userId,uploadDate,isException,uploadedDateStr,uploadedTimeStr --out /home/ubuntu/Harry/emailreport/csv/tradedserial.csv

mongoexport --db mukeshdb --collection validatedserialnumbers --type=csv --fields materialCode,serialNumber,validatedByName,validatedOnDate,validatedOnTime,uploadedBy,uploadedDate,serialNumberType,isException  --out /home/ubuntu/Harry/emailreport/csv/validatedserialnumbers.csv

mongoexport --db zoomdb --collection zoommeeting --type=csv --fields operator,meetingId,topic,type,start_time,duration,deleted,  --out /home/ubuntu/Harry/emailreport/csv/zoommeetings.csv

mongoexport --db zohodb --collection zohousers --type=csv --fields id,first_name,last_name,full_name,email,mobile,phone,dob,status,confirm,role.name,role.id,profile.id,profile.name,Branch,city,Region,state,country,zip,Reporting_To,created_time,Modified_Time  --out /home/ubuntu/Harry/emailreport/csv/Users.csv

mongoexport --db zohodb --collection zohoNotes --type=csv --fields id,Owner.name,Owner.id,Owner.email,Created_By.name,Created_By.id,Created_By.email,Note_Title,Note_Content  --out /home/ubuntu/Harry/emailreport/csv/Notes.csv

mongoexport --db zoomdb --collection zoomslotnotavailable --type=csv --fields topic,scheduleFor,startDateTime,duration  --out /home/ubuntu/Harry/emailreport/csv/slotnotavailable.csv

sed -i '1s/materialCode/Material Code/;1s/serialNumber/Material Serial Number/;1s/validatedByName/Validated By Channel Finance Co/;1s/validatedOnDate/Validation Done On/;1s/validatedOnTime/Validation Time/;1s/uploadedBy/Uploaded By User ID/;1s/uploadedDate/Uploaded On/;1s/serialNumberType/Category/;1s/isException/Exception Upload/;' /home/ubuntu/Harry/emailreport/csv/validatedserialnumbers.csv

#node /home/ubuntu/Harry/emailreport/index.js

#node /home/ubuntu/Harry/emailreport/uploadcsvonftp.js

node /home/ubuntu/Harry/emailreport/uploadvalidatedcsvonftp.js

node /home/ubuntu/Harry/emailreport/uploadzoomcsvtoftp.js

node /home/ubuntu/Harry/emailreport/uploadzohocsvtoftp.js

node /home/ubuntu/Harry/emailreport/slotnotavailable.js

node /home/ubuntu/Harry/emailreport/indexnew.js
