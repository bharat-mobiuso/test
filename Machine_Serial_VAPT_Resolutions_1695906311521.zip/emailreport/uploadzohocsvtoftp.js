var fs = require('fs');
var SSH2Client = require('ssh2').Client;

var connSettings = {
  host: 'ftp.bluestarindia.com',
  port: 22, // Normal is 22 port
  username: 'rajesh_r',
  password: 'n4GN5:9N$Unk' // r@j3sh@321
  // You can use a key file too, read the ssh2 documentation
};

var conn2 = new SSH2Client();
conn2.on('ready', function() {
    conn2.sftp(function(err, sftp) {
         if (err) throw err;
         
        var fs = require("fs"); // Use node filesystem
        var readStream = fs.createReadStream( "/home/ubuntu/Harry/emailreport/csv/Users.csv" );
        var writeStream = sftp.createWriteStream( "/ZohoBulkAPI/Users.csv" );

        writeStream.on('close',function () {
            console.log( "- file transferred succesfully" );
	    conn2.end();
        });

        writeStream.on('end', function () {
            console.log( "sftp connection closed" );
            conn2.close();
        });

        // initiate transfer of file
        readStream.pipe( writeStream );
    });
}).connect(connSettings);


var conn3 = new SSH2Client();
conn3.on('ready', function() {
    conn3.sftp(function(err, sftp) {
         if (err) throw err;

        var fs = require("fs"); // Use node filesystem
        var readStream = fs.createReadStream( "/home/ubuntu/Harry/emailreport/csv/Notes.csv" );
        var writeStream = sftp.createWriteStream( "/ZohoBulkAPI/Notes.csv" );

        writeStream.on('close',function () {
            console.log( "- file transferred succesfully" );
            conn3.end();
        });

        writeStream.on('end', function () {
            console.log( "sftp connection closed" );
            conn3.close();
        });

        // initiate transfer of file
        readStream.pipe( writeStream );
    });
}).connect(connSettings);
