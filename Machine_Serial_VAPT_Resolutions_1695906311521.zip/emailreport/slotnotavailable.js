const nodemailer = require('nodemailer');
const fs = require('fs');


function sendEmail() {
        let transport = nodemailer.createTransport({
                host: 'smtp.sendgrid.com',
                port: 587,
                pool: true,
                auth: {
                        user: 'connect@bluestarindia.com',
                        pass: 'P@ssw0rd'
                },
                tls: {
                        rejectUnauthorized: false
                }
        });

        const message = {
                from: 'connect@bluestarindia.com', // Sender address
                to: "zoomonstarry@bluestarindia.com",         // List of recipients
                subject: "Report - Slot not available", // Subject line
                text: "Dear Team,\n\nPlease find attached csv file.\n\nBest Regards,\nIT Team\n\n", // Plain text body
                attachments: [{ filename: "slotnotavailable.csv", path: "/home/ubuntu/Harry/emailreport/csv/slotnotavailable.csv" }]
        };

        transport.sendMail(message, function (err, info) {
                if (err) {
                        console.log("Error");
                        console.log(err);
			transport.close();
                } else {
                        console.log("Success");
                        console.log(info);
			transport.close();
                }
        });
}

sendEmail();
